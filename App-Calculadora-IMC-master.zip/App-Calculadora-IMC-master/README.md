<h1 align="center">
  📈 App Calculadora de IMC
</h1>


## :rocket: Sobre o projeto

Estudando um pouco de React Native eu desenvolvi este aplicativo simples que efetua o cálculo de IMC.

Nele o usuário informa a altura e a sua massa corporal. 
Quando o usuário clica em "Calcular" esses dados são utilizados na fórmula de IMC que efetua o cálculo e exibe o resultado na tela do app.

Abaixo do resultado da fórmula do IMC também é apresentada a categoria em que o usuário se encaixa, sendo: Magreza grave, magreza moderada, magreza leve, saudável, sobrepeso, obesidade grau I, obesidade grau II e obesidade grau III"

## :computer: Tecnologia usada:

- `React Native`

## :bulb: Tela

![screencast-Genymotion-2020-08-05_17 22 56 606](https://user-images.githubusercontent.com/23708544/89460458-b43d0c80-d740-11ea-9f67-cc2b0e57fd73.gif)
